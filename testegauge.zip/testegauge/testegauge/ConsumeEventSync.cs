﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Net;
using System.Xml;
using System.Xml.Linq;

namespace testegauge
{
    public class ConsumeEventSync
    {
        public static List<r> data = new List<r>();

        public void GetAllEventData() //Get All Events Records  
        {
            Console.WriteLine("made it here");
            var result = "";

            using (var client = new WebClient()) //WebClient  
            {
                //                client.Headers.Add("Content-Type:/cgi-bin/egauge?tot"); //Content-Type  
                //                client.Headers.Add("Accept:/cgi-bin/egauge?tot");
                result = client.DownloadString("http://egauge33748.egaug.es//cgi-bin/egauge?tot"); //URI  
            }
               
            Console.WriteLine(Environment.NewLine + result);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(result);
            XmlNode snode = doc.DocumentElement.SelectSingleNode("/data/ts");
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/data/r");

            string tempts = snode.InnerText;
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            ts = dtDateTime.AddSeconds(Convert.ToDouble(tempts)).ToUniversalTime();

            //List<r> data = new List<r>();

            foreach (XmlNode node in nodes)
                {
                r r = new r();
                r.v = node.SelectSingleNode("v").InnerText;
                r.t = node.Attributes["t"].Value;
                r.n = node.Attributes["n"].Value;
                Console.WriteLine("new node: " + r.n);
                data.Add(r);
                }

            Console.WriteLine("xml parsed supposedly");

            foreach (var item in data)
            {
                Console.WriteLine("datatype = " + item.t + "; device = " + item.n + "; value = " + item.v);
            }
        }
        public static DateTime ts = new DateTime();
    }


    public class r
        {
            public string t;
            public string n;
            public string v;
        }
}
