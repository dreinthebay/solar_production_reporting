﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.Threading;
using MySql.Data.MySqlClient;
using System.Timers;

namespace testegauge
{
    class Program
    {
        static void Main(string[] args)
        { 

            Console.WriteLine("Hello World!");
            ConsumeEventSync objsync = new ConsumeEventSync();
            objsync.GetAllEventData();

            Thread.Sleep(5000);
            sqlinsert sqlinsert = new sqlinsert();
            sqlinsert.sqlconn();
            Console.WriteLine("done");
            Console.ReadLine();


        }
    }
}
