﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading;

namespace testegauge
{
    public class sqlinsert
    {
        public void sqlconn()
        {
            Thread.Sleep(10000);
            Console.WriteLine("waking up");
            string myConnectionString = @"server=localhost;database=test;uid=ncsadmin;pwd=BlueOcean;";

            //con.ConnectionString = "Persist Security Info=False;database=test;server=localhost;Connect Timeout=30;user id=ncsadmin; pwd=BlueOcean";
            try
            {
                using MySqlConnection con = new MySqlConnection(myConnectionString);
                con.Open();
                foreach (var item in ConsumeEventSync.data)
                {
                    using var cmd = new MySqlCommand();
                    cmd.CommandText = "insert into test.testdata values (@utctime,@devicetime,'"
                         + item.t + "','" + item.n + "'," + item.v + ")";
                    cmd.Parameters.AddWithValue("@utctime", DateTime.UtcNow);
                    cmd.Parameters.AddWithValue("@devicetime", ConsumeEventSync.ts);
                    cmd.Connection = con;
                    Console.WriteLine("connection made");
                    cmd.ExecuteNonQuery();
                }
                //var stm = "select * from test.testdata";
                //var cmd = new MySqlCommand(stm, con);
                //var version = cmd.ExecuteScalar().ToString();               
                //Console.WriteLine($"MySQL version: {version}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("exception found!");
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
